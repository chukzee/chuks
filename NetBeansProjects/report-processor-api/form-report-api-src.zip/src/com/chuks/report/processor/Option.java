/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chuks.report.processor;

/**
 *
 * @author Chuks Alimele<chuksalimele at yahoo.com>
 */
public enum Option {

    SUCCESS,
    WARNING,
    INFO,
    ERROR,
    OK,
    OK_CANCEL,
    YES,
    NO,
    CANCEL,
    YES_NO,
    YES_NO_CANCEL,
    CLOSED,

}
