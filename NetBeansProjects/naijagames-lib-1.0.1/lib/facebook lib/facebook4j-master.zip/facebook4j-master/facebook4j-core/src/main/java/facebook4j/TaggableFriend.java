package facebook4j;

public interface TaggableFriend {
	
	String getToken();
	String getName();
	Picture getPicture();
}
