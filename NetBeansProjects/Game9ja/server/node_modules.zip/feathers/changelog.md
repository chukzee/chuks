## Changelog

Please refer to the full [changelog at docs.feathersjs.com](http://docs.feathersjs.com/changelog.html).
