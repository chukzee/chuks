module.exports = require('./lib/bundled');
