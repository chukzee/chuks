
module.exports = exports = require("./lib/pmx");
